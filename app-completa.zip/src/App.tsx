/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Navbar from './components/Navbar';
import MasterPlan from './components/MasterPlan';
import WeekDetail from './components/WeekDetail';
import AIAssistant from './components/AIAssistant';
import CustomRoutines, { Routine } from './components/CustomRoutines';
import Login from './components/Login';
import BioHacks from './components/BioHacks';
import Progress from './components/Progress';
import { WEEKS_DATA } from './data';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState('masterPlan');
  const [selectedWeekId, setSelectedWeekId] = useState('week1');
  const [completedDays, setCompletedDays] = useState<string[]>([]);
  const [customRoutines, setCustomRoutines] = useState<Routine[]>([]);
  const [userProfile, setUserProfile] = useState({ name: 'Usuario', avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAw7RSlBk8x-vBaqZ_uXC7g2jGQhgx9oOAY2ghN9gZx17RtihHGvpu6K7lRXRTb3T8tbD2t16eB_jhUL69GZqvoUbcGmmAadj67EQMv9C2fDmy0Z_awb-Oj1vs20BMJ0pH5wexECgG2grhlAP8xtSge9csi4vR_h6QfOgt3L6IGPCzW0H3wHJthAxDYkHcjJmDiuTb4hdiB42NgkEs5rxU4JigUM_7iSQ01S7sYqfwBloVecq9S5QeYqLViAuIfhrW177ObnYGHM0g' });
  const [notifications, setNotifications] = useState([
    { id: 1, title: '¡Bienvenido!', message: 'Estás listo para comenzar tu transformación. Revisa el Plan Maestro.', time: 'Ahora', icon: 'military_tech', color: 'text-primary', bg: 'bg-primary/20' }
  ]);

  const handleNavigateToWeek = (weekId: string) => {
    setSelectedWeekId(weekId);
    setCurrentView('weekDetail');
  };

  const handleDayComplete = (dayId: string, weekId: string) => {
    if (!completedDays.includes(dayId)) {
      const newCompletedDays = [...completedDays, dayId];
      setCompletedDays(newCompletedDays);
      
      const week = WEEKS_DATA.find(w => w.id === weekId);
      if (week) {
        const weekDays = week.days.map(d => d.id);
        const isNowCompleted = weekDays.every(id => newCompletedDays.includes(id));
        if (isNowCompleted) {
           setNotifications(prev => [{
             id: Date.now(),
             title: `¡Semana ${week.number} Completada!`,
             message: `Has finalizado todos los ejercicios de la semana ${week.number}. ¡Sigue así!`,
             time: 'Ahora',
             icon: 'emoji_events',
             color: 'text-green-500',
             bg: 'bg-green-500/20'
           }, ...prev]);
        }
      }
    }
  };

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      <Navbar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        userProfile={userProfile}
        setUserProfile={setUserProfile}
        notifications={notifications}
      />
      <main className="flex-1 flex justify-center py-8 px-4 sm:px-6 lg:px-8">
        {currentView === 'masterPlan' && (
          <MasterPlan 
            onNavigate={handleNavigateToWeek} 
            completedDays={completedDays} 
            weeksData={WEEKS_DATA} 
          />
        )}
        {currentView === 'weekDetail' && (
          <WeekDetail 
            onBack={() => setCurrentView('masterPlan')} 
            weekId={selectedWeekId}
            weeksData={WEEKS_DATA}
            completedDays={completedDays}
            onDayComplete={handleDayComplete}
            onNavigateToWeek={handleNavigateToWeek}
          />
        )}
        {currentView === 'customRoutines' && (
          <CustomRoutines routines={customRoutines} setRoutines={setCustomRoutines} />
        )}
        {currentView === 'bioHacks' && (
          <BioHacks />
        )}
        {currentView === 'progress' && (
          <Progress completedDays={completedDays} />
        )}
      </main>
      <AIAssistant />
    </div>
  );
}
