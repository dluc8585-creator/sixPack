import { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from "react-markdown";

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface ChatMessage {
  role: "user" | "model";
  text: string;
}

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"chat" | "vision" | "video">(
    "chat",
  );

  // Chat State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Vision State
  const [visionImage, setVisionImage] = useState<File | null>(null);
  const [visionPrompt, setVisionPrompt] = useState("");
  const [visionResult, setVisionResult] = useState("");
  const [isVisionLoading, setIsVisionLoading] = useState(false);

  // Video State
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPrompt, setVideoPrompt] = useState("");
  const [videoResult, setVideoResult] = useState("");
  const [isVideoLoading, setIsVideoLoading] = useState(false);

  // Scroll to bottom of chat
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatHistory, isOpen, activeTab]);

  // Helper to convert file to base64
  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(",")[1]);
      };
      reader.onerror = (error) => reject(error);
    });

  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const newHistory: ChatMessage[] = [
      ...chatHistory,
      { role: "user", text: chatInput },
    ];
    setChatHistory(newHistory);
    setChatInput("");
    setIsChatLoading(true);

    try {
      const contents = newHistory.map((msg) => ({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.text }],
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: contents as any,
      });

      setChatHistory([
        ...newHistory,
        { role: "model", text: response.text || "" },
      ]);
    } catch (error) {
      console.error(error);
      setChatHistory([
        ...newHistory,
        { role: "model", text: "Error: Could not get response." },
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleVisionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!visionImage || !visionPrompt.trim()) return;

    setIsVisionLoading(true);
    setVisionResult("");

    try {
      const base64Data = await fileToBase64(visionImage);
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: {
          parts: [
            { inlineData: { mimeType: visionImage.type, data: base64Data } },
            { text: visionPrompt },
          ],
        },
      });
      setVisionResult(response.text || "");
    } catch (error) {
      console.error(error);
      setVisionResult("Error analyzing image.");
    } finally {
      setIsVisionLoading(false);
    }
  };

  const handleVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoFile || !videoPrompt.trim()) return;

    setIsVideoLoading(true);
    setVideoResult("");

    try {
      // 10MB limit for safety in browser
      if (videoFile.size > 10 * 1024 * 1024) {
        setVideoResult(
          "Error: Video file is too large. Please upload a video smaller than 10MB.",
        );
        setIsVideoLoading(false);
        return;
      }

      const base64Data = await fileToBase64(videoFile);
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: {
          parts: [
            { inlineData: { mimeType: videoFile.type, data: base64Data } },
            { text: videoPrompt },
          ],
        },
      });
      setVideoResult(response.text || "");
    } catch (error) {
      console.error(error);
      setVideoResult(
        "Error analyzing video. Ensure it is a supported format and size.",
      );
    } finally {
      setIsVideoLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 size-14 bg-primary hover:bg-primary-dark text-white rounded-full shadow-[0_0_20px_rgba(242,127,13,0.5)] flex items-center justify-center z-50 transition-transform hover:scale-110"
      >
        <span className="material-symbols-outlined text-3xl">
          {isOpen ? "close" : "smart_toy"}
        </span>
      </button>

      {/* Assistant Panel */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-[400px] max-w-[calc(100vw-3rem)] h-[600px] max-h-[calc(100vh-8rem)] bg-surface-dark border border-surface-border rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50">
          {/* Header */}
          <div className="bg-background-dark p-4 border-b border-surface-border flex items-center gap-3">
            <div className="size-8 bg-primary/20 rounded-full flex items-center justify-center text-primary">
              <span className="material-symbols-outlined">smart_toy</span>
            </div>
            <div>
              <h3 className="text-white font-bold">AI Coach</h3>
              <p className="text-xs text-primary">Powered by Gemini 3.1 Pro</p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-surface-border bg-background-dark/50">
            <button
              onClick={() => setActiveTab("chat")}
              className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === "chat" ? "text-primary border-b-2 border-primary" : "text-slate-400 hover:text-white"}`}
            >
              <span className="material-symbols-outlined text-[18px]">
                voice_chat
              </span>{" "}
              Chat
            </button>
            <button
              onClick={() => setActiveTab("vision")}
              className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === "vision" ? "text-primary border-b-2 border-primary" : "text-slate-400 hover:text-white"}`}
            >
              <span className="material-symbols-outlined text-[18px]">
                document_scanner
              </span>{" "}
              Vision
            </button>
            <button
              onClick={() => setActiveTab("video")}
              className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${activeTab === "video" ? "text-primary border-b-2 border-primary" : "text-slate-400 hover:text-white"}`}
            >
              <span className="material-symbols-outlined text-[18px]">
                video_library
              </span>{" "}
              Video
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-4 bg-background-dark/30">
            {/* Chat Tab */}
            {activeTab === "chat" && (
              <div className="flex flex-col h-full">
                <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
                  {chatHistory.length === 0 && (
                    <div className="text-center text-slate-500 mt-10">
                      <span className="material-symbols-outlined text-4xl mb-2 opacity-50">
                        forum
                      </span>
                      <p>
                        Ask me anything about your training, nutrition, or
                        recovery!
                      </p>
                    </div>
                  )}
                  {chatHistory.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl px-4 py-2 ${msg.role === "user" ? "bg-primary text-black" : "bg-surface-border text-white"}`}
                      >
                        {msg.role === "model" ? (
                          <div className="prose prose-invert prose-sm max-w-none">
                            <ReactMarkdown>{msg.text}</ReactMarkdown>
                          </div>
                        ) : (
                          <p className="text-sm font-medium">{msg.text}</p>
                        )}
                      </div>
                    </div>
                  ))}
                  {isChatLoading && (
                    <div className="flex justify-start">
                      <div className="bg-surface-border text-white rounded-2xl px-4 py-2 flex items-center gap-2">
                        <span className="size-2 bg-primary rounded-full animate-bounce"></span>
                        <span
                          className="size-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></span>
                        <span
                          className="size-2 bg-primary rounded-full animate-bounce"
                          style={{ animationDelay: "0.4s" }}
                        ></span>
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>
                <form
                  onSubmit={handleChatSubmit}
                  className="flex gap-2 mt-auto"
                >
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Type your question..."
                    className="flex-1 bg-surface-dark border border-surface-border rounded-xl px-4 py-2 text-white focus:outline-none focus:border-primary"
                    disabled={isChatLoading}
                  />
                  <button
                    type="submit"
                    disabled={isChatLoading || !chatInput.trim()}
                    className="bg-primary hover:bg-primary-dark text-black rounded-xl px-4 flex items-center justify-center disabled:opacity-50"
                  >
                    <span className="material-symbols-outlined">send</span>
                  </button>
                </form>
              </div>
            )}

            {/* Vision Tab */}
            {activeTab === "vision" && (
              <div className="flex flex-col h-full">
                <form
                  onSubmit={handleVisionSubmit}
                  className="flex flex-col gap-4"
                >
                  <div className="border-2 border-dashed border-surface-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors relative">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          setVisionImage(e.target.files[0]);
                        }
                      }}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    {visionImage ? (
                      <div className="flex flex-col items-center gap-2">
                        <span className="material-symbols-outlined text-primary text-3xl">
                          image
                        </span>
                        <p className="text-sm text-white truncate max-w-full">
                          {visionImage.name}
                        </p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <span className="material-symbols-outlined text-slate-500 text-3xl">
                          add_photo_alternate
                        </span>
                        <p className="text-sm text-slate-400">
                          Click or drag image to upload
                        </p>
                      </div>
                    )}
                  </div>
                  <textarea
                    value={visionPrompt}
                    onChange={(e) => setVisionPrompt(e.target.value)}
                    placeholder="What do you want to know about this image? (e.g., 'Analyze my form', 'Estimate calories')"
                    className="w-full bg-surface-dark border border-surface-border rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary resize-none h-24"
                  />
                  <button
                    type="submit"
                    disabled={
                      isVisionLoading || !visionImage || !visionPrompt.trim()
                    }
                    className="w-full bg-primary hover:bg-primary-dark text-black font-bold py-3 rounded-xl flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isVisionLoading ? (
                      <span className="material-symbols-outlined animate-spin">
                        progress_activity
                      </span>
                    ) : (
                      <span className="material-symbols-outlined">
                        auto_awesome
                      </span>
                    )}
                    Analyze Image
                  </button>
                </form>
                {visionResult && (
                  <div className="mt-6 p-4 bg-surface-dark border border-surface-border rounded-xl flex-1 overflow-y-auto">
                    <h4 className="text-primary text-sm font-bold mb-2 uppercase">
                      Analysis Result
                    </h4>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{visionResult}</ReactMarkdown>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Video Tab */}
            {activeTab === "video" && (
              <div className="flex flex-col h-full">
                <form
                  onSubmit={handleVideoSubmit}
                  className="flex flex-col gap-4"
                >
                  <div className="border-2 border-dashed border-surface-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors relative">
                    <input
                      type="file"
                      accept="video/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files.length > 0) {
                          setVideoFile(e.target.files[0]);
                        }
                      }}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    {videoFile ? (
                      <div className="flex flex-col items-center gap-2">
                        <span className="material-symbols-outlined text-primary text-3xl">
                          movie
                        </span>
                        <p className="text-sm text-white truncate max-w-full">
                          {videoFile.name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {(videoFile.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <span className="material-symbols-outlined text-slate-500 text-3xl">
                          video_file
                        </span>
                        <p className="text-sm text-slate-400">
                          Click or drag video to upload (&lt; 10MB)
                        </p>
                      </div>
                    )}
                  </div>
                  <textarea
                    value={videoPrompt}
                    onChange={(e) => setVideoPrompt(e.target.value)}
                    placeholder="What should I look for in this video? (e.g., 'Check my squat depth', 'Analyze my running gait')"
                    className="w-full bg-surface-dark border border-surface-border rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary resize-none h-24"
                  />
                  <button
                    type="submit"
                    disabled={
                      isVideoLoading || !videoFile || !videoPrompt.trim()
                    }
                    className="w-full bg-primary hover:bg-primary-dark text-black font-bold py-3 rounded-xl flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isVideoLoading ? (
                      <span className="material-symbols-outlined animate-spin">
                        progress_activity
                      </span>
                    ) : (
                      <span className="material-symbols-outlined">
                        auto_awesome
                      </span>
                    )}
                    Analyze Video
                  </button>
                </form>
                {videoResult && (
                  <div className="mt-6 p-4 bg-surface-dark border border-surface-border rounded-xl flex-1 overflow-y-auto">
                    <h4 className="text-primary text-sm font-bold mb-2 uppercase">
                      Analysis Result
                    </h4>
                    <div className="prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{videoResult}</ReactMarkdown>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
